CREATE INDEX idx_locacoes_status ON locacoes(status);
CREATE INDEX idx_pagamentos_data ON pagamentos(data_pagamento);
