package com.mottu.repositorio;
import com.mottu.dominio.Entregador;
import org.springframework.data.jpa.repository.JpaRepository;
public interface EntregadorRepositorio extends JpaRepository<Entregador, Long> {}
