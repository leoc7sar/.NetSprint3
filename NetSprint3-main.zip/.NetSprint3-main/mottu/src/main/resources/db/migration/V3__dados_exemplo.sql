INSERT INTO entregadores(nome,cnh,telefone) VALUES
 ('João Silva','CNH123','11-90000-0001'),
 ('Maria Souza','CNH456','11-90000-0002');

INSERT INTO motos(placa,modelo,ano) VALUES
 ('ABC1D23','Honda CG 160',2022),
 ('EFG4H56','Yamaha Fazer 250',2023);
